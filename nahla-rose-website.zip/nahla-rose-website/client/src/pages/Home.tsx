import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Sparkles, Moon, Leaf, Heart } from "lucide-react";

export default function Home() {
  return (
    <div className="min-h-screen">
      {/* Header */}
      <header className="border-b border-border/40 bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60 sticky top-0 z-50">
        <div className="container flex h-20 items-center justify-between">
          <div className="flex items-center gap-3">
            <img src="/logo.png" alt="Nahla Rose" className="h-12 w-12 object-contain" />
            <div>
              <h1 className="text-2xl font-semibold text-foreground">Nahla Rose</h1>
              <p className="text-xs text-muted-foreground">Botanical Hair Care</p>
            </div>
          </div>
          <nav className="hidden md:flex items-center gap-8">
            <a href="#story" className="text-sm font-medium hover:text-primary transition-colors">Our Story</a>
            <a href="#products" className="text-sm font-medium hover:text-primary transition-colors">Products</a>
            <a href="#ritual" className="text-sm font-medium hover:text-primary transition-colors">The Ritual</a>
            <Button variant="default" size="sm">Shop Now</Button>
          </nav>
        </div>
      </header>

      {/* Hero Section */}
      <section className="relative overflow-hidden">
        <div className="absolute inset-0 bg-gradient-to-br from-primary/5 via-secondary/5 to-accent/5" />
        <div className="container relative py-24 md:py-32">
          <div className="grid lg:grid-cols-2 gap-12 items-center">
            <div className="space-y-8">
              <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-accent/10 border border-accent/20">
                <Sparkles className="h-4 w-4 text-accent" />
                <span className="text-sm font-medium text-accent-foreground">Inspired by Lioness Energy & Full Moon Magic</span>
              </div>
              <h2 className="text-5xl md:text-6xl lg:text-7xl font-bold leading-tight">
                Transform Hair Care Into{" "}
                <span className="bg-gradient-to-r from-primary via-secondary to-accent bg-clip-text text-transparent">
                  Sacred Ritual
                </span>
              </h2>
              <p className="text-lg text-muted-foreground max-w-xl">
                Pure botanical teas and oils crafted to nourish your crown. Infuse your daily routine with intention, 
                connect with lunar rhythms, and celebrate the goddess within.
              </p>
              <div className="flex flex-col sm:flex-row gap-4">
                <Button size="lg" className="text-base">
                  Explore Our Collection
                </Button>
                <Button size="lg" variant="outline" className="text-base">
                  Learn About Rituals
                </Button>
              </div>
            </div>
            <div className="relative">
              <div className="absolute inset-0 bg-gradient-to-tr from-primary/20 via-transparent to-accent/20 rounded-3xl blur-3xl" />
              <img 
                src="/hero.jpg" 
                alt="Natural beauty and botanical elements" 
                className="relative rounded-3xl shadow-2xl w-full h-auto object-cover"
              />
            </div>
          </div>
        </div>
      </section>

      {/* Story Section */}
      <section id="story" className="py-24 bg-card">
        <div className="container">
          <div className="max-w-3xl mx-auto text-center space-y-6">
            <h3 className="text-4xl md:text-5xl font-bold">The Nahla Rose Story</h3>
            <p className="text-lg text-muted-foreground leading-relaxed">
              Born from a mother's love and a daughter's spirit, Nahla Rose captures the essence of a child 
              blessed by the full moon with a Leo's lioness heart. Her birth color, green, represents life and growth. 
              Purple signifies her spiritual depth. Rose gold reflects her inner light.
            </p>
            <p className="text-lg text-muted-foreground leading-relaxed">
              This brand is a tribute to that energy—a collection of simple, pure hair care products designed to 
              turn a daily task into a cherished ritual. It's an invitation to connect with your own inner goddess, 
              to infuse your routine with intention, and to celebrate the sacred beauty of your crown.
            </p>
          </div>
        </div>
      </section>

      {/* Values Section */}
      <section className="py-24">
        <div className="container">
          <div className="grid md:grid-cols-3 gap-8">
            <Card className="border-2 hover:border-primary/50 transition-colors">
              <CardContent className="pt-8 space-y-4 text-center">
                <div className="mx-auto w-16 h-16 rounded-full bg-primary/10 flex items-center justify-center">
                  <Leaf className="h-8 w-8 text-primary" />
                </div>
                <h4 className="text-xl font-semibold">Pure Botanicals</h4>
                <p className="text-muted-foreground">
                  Certified organic herbs and oils, carefully selected for their therapeutic properties and 
                  traditional use in hair care.
                </p>
              </CardContent>
            </Card>
            
            <Card className="border-2 hover:border-secondary/50 transition-colors">
              <CardContent className="pt-8 space-y-4 text-center">
                <div className="mx-auto w-16 h-16 rounded-full bg-secondary/10 flex items-center justify-center">
                  <Moon className="h-8 w-8 text-secondary" />
                </div>
                <h4 className="text-xl font-semibold">Lunar Rituals</h4>
                <p className="text-muted-foreground">
                  Each product includes guidance for incorporating moon phases into your hair care practice, 
                  empowering you to lead the ritual.
                </p>
              </CardContent>
            </Card>
            
            <Card className="border-2 hover:border-accent/50 transition-colors">
              <CardContent className="pt-8 space-y-4 text-center">
                <div className="mx-auto w-16 h-16 rounded-full bg-accent/10 flex items-center justify-center">
                  <Heart className="h-8 w-8 text-accent" />
                </div>
                <h4 className="text-xl font-semibold">Intentional Care</h4>
                <p className="text-muted-foreground">
                  Transform your hair care into an act of self-love with affirmations and ritual guides 
                  included with every product.
                </p>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      {/* Products Section */}
      <section id="products" className="py-24 bg-gradient-to-b from-background to-card">
        <div className="container">
          <div className="text-center space-y-4 mb-16">
            <h3 className="text-4xl md:text-5xl font-bold">Our Collection</h3>
            <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
              Four carefully crafted products to nourish, strengthen, and celebrate your hair
            </p>
          </div>
          
          <div className="max-w-5xl mx-auto">
            <img 
              src="/products.png" 
              alt="Nahla Rose product collection" 
              className="w-full h-auto rounded-2xl shadow-2xl"
            />
          </div>

          <div className="grid md:grid-cols-2 gap-8 mt-16 max-w-4xl mx-auto">
            <Card className="overflow-hidden hover:shadow-xl transition-shadow">
              <div className="bg-gradient-to-br from-primary/10 to-primary/5 p-6">
                <h4 className="text-2xl font-semibold mb-2">Lioness Strength Hair Rinse Tea</h4>
                <p className="text-sm text-muted-foreground mb-4">For Growth & Fortification</p>
                <p className="text-sm leading-relaxed">
                  A fortifying blend of Nettle, Rosemary, Chamomile, Lavender, and Rose. Use 1-2 times weekly 
                  to promote growth and strengthen your hair from root to tip.
                </p>
                <div className="mt-6 flex items-center justify-between">
                  <span className="text-2xl font-bold">$18</span>
                  <Button variant="outline" size="sm">Learn More</Button>
                </div>
              </div>
            </Card>

            <Card className="overflow-hidden hover:shadow-xl transition-shadow">
              <div className="bg-gradient-to-br from-secondary/10 to-secondary/5 p-6">
                <h4 className="text-2xl font-semibold mb-2">Full Moon Goddess Moisture Tea</h4>
                <p className="text-sm text-muted-foreground mb-4">For Daily Hydration</p>
                <p className="text-sm leading-relaxed">
                  A hydrating spray base of Rose, Chamomile, Lavender, Nettle, and Marshmallow Root. 
                  Mist daily for moisture, shine, and goddess energy.
                </p>
                <div className="mt-6 flex items-center justify-between">
                  <span className="text-2xl font-bold">$18</span>
                  <Button variant="outline" size="sm">Learn More</Button>
                </div>
              </div>
            </Card>

            <Card className="overflow-hidden hover:shadow-xl transition-shadow">
              <div className="bg-gradient-to-br from-accent/10 to-accent/5 p-6">
                <h4 className="text-2xl font-semibold mb-2">Nahla's Crown Oil</h4>
                <p className="text-sm text-muted-foreground mb-4">For Growth & Strength</p>
                <p className="text-sm leading-relaxed">
                  A growth-stimulating treatment oil with Jojoba, Sweet Almond, infused with Rosemary, Nettle, 
                  and Lavender. Massage into scalp for a crowning ritual.
                </p>
                <div className="mt-6 flex items-center justify-between">
                  <span className="text-2xl font-bold">$32</span>
                  <Button variant="outline" size="sm">Learn More</Button>
                </div>
              </div>
            </Card>

            <Card className="overflow-hidden hover:shadow-xl transition-shadow">
              <div className="bg-gradient-to-br from-primary/10 via-secondary/5 to-accent/10 p-6">
                <h4 className="text-2xl font-semibold mb-2">Moon Glow Sealing Oil</h4>
                <p className="text-sm text-muted-foreground mb-4">For Sealing & Shine</p>
                <p className="text-sm leading-relaxed">
                  A lightweight finishing oil with Jojoba and Grapeseed, infused with Chamomile and Rose. 
                  Seal in moisture and radiate your inner glow.
                </p>
                <div className="mt-6 flex items-center justify-between">
                  <span className="text-2xl font-bold">$32</span>
                  <Button variant="outline" size="sm">Learn More</Button>
                </div>
              </div>
            </Card>
          </div>
        </div>
      </section>

      {/* Ritual Section */}
      <section id="ritual" className="py-24">
        <div className="container">
          <div className="max-w-4xl mx-auto">
            <div className="text-center space-y-4 mb-12">
              <h3 className="text-4xl md:text-5xl font-bold">Your Hair Care Ritual</h3>
              <p className="text-lg text-muted-foreground">
                Transform your routine into a sacred practice with moon phase guidance and intention
              </p>
            </div>

            <div className="grid md:grid-cols-2 gap-8">
              <div className="space-y-6">
                <div className="flex gap-4">
                  <div className="flex-shrink-0 w-12 h-12 rounded-full bg-primary/10 flex items-center justify-center">
                    <span className="text-xl font-bold text-primary">1</span>
                  </div>
                  <div>
                    <h5 className="text-lg font-semibold mb-2">Set Your Intention</h5>
                    <p className="text-muted-foreground">
                      Each product includes an affirmation card. Read it aloud or silently as you begin your ritual.
                    </p>
                  </div>
                </div>

                <div className="flex gap-4">
                  <div className="flex-shrink-0 w-12 h-12 rounded-full bg-secondary/10 flex items-center justify-center">
                    <span className="text-xl font-bold text-secondary">2</span>
                  </div>
                  <div>
                    <h5 className="text-lg font-semibold mb-2">Connect with the Moon</h5>
                    <p className="text-muted-foreground">
                      New moon for growth intentions, full moon for celebration and nourishment. Follow the lunar guide included.
                    </p>
                  </div>
                </div>

                <div className="flex gap-4">
                  <div className="flex-shrink-0 w-12 h-12 rounded-full bg-accent/10 flex items-center justify-center">
                    <span className="text-xl font-bold text-accent">3</span>
                  </div>
                  <div>
                    <h5 className="text-lg font-semibold mb-2">Nourish with Presence</h5>
                    <p className="text-muted-foreground">
                      Apply your tea or oil mindfully, massaging your scalp with circular motions, breathing deeply.
                    </p>
                  </div>
                </div>

                <div className="flex gap-4">
                  <div className="flex-shrink-0 w-12 h-12 rounded-full bg-primary/10 flex items-center justify-center">
                    <span className="text-xl font-bold text-primary">4</span>
                  </div>
                  <div>
                    <h5 className="text-lg font-semibold mb-2">Celebrate Your Crown</h5>
                    <p className="text-muted-foreground">
                      As you complete your ritual, affirm your beauty, strength, and the divine energy within you.
                    </p>
                  </div>
                </div>
              </div>

              <Card className="bg-gradient-to-br from-primary/5 via-secondary/5 to-accent/5 border-2">
                <CardContent className="pt-8 space-y-4">
                  <h5 className="text-xl font-semibold">Moon Phase Guide</h5>
                  <div className="space-y-3">
                    <div className="flex items-start gap-3">
                      <Moon className="h-5 w-5 text-primary mt-1" />
                      <div>
                        <p className="font-medium">New Moon</p>
                        <p className="text-sm text-muted-foreground">Set intentions for growth, use growth oil</p>
                      </div>
                    </div>
                    <div className="flex items-start gap-3">
                      <Moon className="h-5 w-5 text-secondary mt-1" />
                      <div>
                        <p className="font-medium">Waxing Moon</p>
                        <p className="text-sm text-muted-foreground">Build momentum, strengthen with tea rinse</p>
                      </div>
                    </div>
                    <div className="flex items-start gap-3">
                      <Moon className="h-5 w-5 text-accent mt-1" />
                      <div>
                        <p className="font-medium">Full Moon</p>
                        <p className="text-sm text-muted-foreground">Celebrate and nourish, deep conditioning</p>
                      </div>
                    </div>
                    <div className="flex items-start gap-3">
                      <Moon className="h-5 w-5 text-muted-foreground mt-1" />
                      <div>
                        <p className="font-medium">Waning Moon</p>
                        <p className="text-sm text-muted-foreground">Release and cleanse, gentle tea rinse</p>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-24 bg-gradient-to-r from-primary/10 via-secondary/10 to-accent/10">
        <div className="container">
          <div className="max-w-3xl mx-auto text-center space-y-8">
            <h3 className="text-4xl md:text-5xl font-bold">Begin Your Ritual Today</h3>
            <p className="text-lg text-muted-foreground">
              Join our community of modern mystics who are transforming their hair care into a sacred practice. 
              Receive moon phase reminders, ritual guides, and exclusive offers.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <Button size="lg" className="text-base">
                Shop the Collection
              </Button>
              <Button size="lg" variant="outline" className="text-base">
                Join Our Community
              </Button>
            </div>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="border-t py-12 bg-card">
        <div className="container">
          <div className="grid md:grid-cols-4 gap-8">
            <div className="space-y-4">
              <div className="flex items-center gap-2">
                <img src="/logo.png" alt="Nahla Rose" className="h-10 w-10 object-contain" />
                <span className="text-lg font-semibold">Nahla Rose</span>
              </div>
              <p className="text-sm text-muted-foreground">
                Botanical hair care inspired by lioness energy and full moon magic.
              </p>
            </div>
            
            <div>
              <h6 className="font-semibold mb-4">Shop</h6>
              <ul className="space-y-2 text-sm text-muted-foreground">
                <li><a href="#" className="hover:text-primary transition-colors">Hair Teas</a></li>
                <li><a href="#" className="hover:text-primary transition-colors">Hair Oils</a></li>
                <li><a href="#" className="hover:text-primary transition-colors">Ritual Sets</a></li>
                <li><a href="#" className="hover:text-primary transition-colors">Gift Cards</a></li>
              </ul>
            </div>
            
            <div>
              <h6 className="font-semibold mb-4">Learn</h6>
              <ul className="space-y-2 text-sm text-muted-foreground">
                <li><a href="#" className="hover:text-primary transition-colors">Our Story</a></li>
                <li><a href="#" className="hover:text-primary transition-colors">Ritual Guides</a></li>
                <li><a href="#" className="hover:text-primary transition-colors">Ingredient Benefits</a></li>
                <li><a href="#" className="hover:text-primary transition-colors">Moon Phases</a></li>
              </ul>
            </div>
            
            <div>
              <h6 className="font-semibold mb-4">Connect</h6>
              <ul className="space-y-2 text-sm text-muted-foreground">
                <li><a href="#" className="hover:text-primary transition-colors">Instagram</a></li>
                <li><a href="#" className="hover:text-primary transition-colors">Pinterest</a></li>
                <li><a href="#" className="hover:text-primary transition-colors">Contact Us</a></li>
                <li><a href="#" className="hover:text-primary transition-colors">Subscribe</a></li>
              </ul>
            </div>
          </div>
          
          <div className="mt-12 pt-8 border-t text-center text-sm text-muted-foreground">
            <p>&copy; 2025 Nahla Rose Hair Care. All rights reserved.</p>
          </div>
        </div>
      </footer>
    </div>
  );
}

